# Nubia Leo Trading Academy

A simple static website for classes, live sessions, groups, and resources — built with plain HTML/CSS.

**Theme**: Deep royal purple + gold  
**Author**: Nubia Leo  
**Contact**: nubiavkleo12@gmail.com

---

## 🚀 Quick Start (GitHub Pages)

1. Create a new GitHub repository (e.g., `nl-trading-academy`).
2. Download **`nlta-github.zip`** and extract it.
3. Drag & drop all files into your GitHub repo (or push via Git).
4. Enable **GitHub Pages**:
   - Go to **Settings → Pages**.
   - Select **Deploy from a branch**.
   - Branch: `main`, Folder: `/ (root)`.
   - Click **Save**. Your site will be available at `https://<your-username>.github.io/<repo-name>/`.

> Alternatively, keep the provided GitHub Actions workflow (in `.github/workflows/pages.yml`).  
> It will auto-build and publish Pages on every push to `main`.

---

## 🔗 Update Your Calendly Links

In **`classes.html`**:
```html
<iframe src="https://calendly.com/YOUR-CALENDLY-USERNAME/class" ...></iframe>
```
In **`oneonone.html`**:
```html
<iframe src="https://calendly.com/YOUR-CALENDLY-USERNAME/one-on-one" ...></iframe>
```

---

## 🗂️ Project Structure

```
.
├── index.html
├── classes.html
├── oneonone.html
├── groups.html
├── live.html
├── resources.html
├── about.html
├── style.css
├── .nojekyll
├── .github/
│   └── workflows/
│       └── pages.yml
└── README.md
```

**Note**: `.nojekyll` disables Jekyll on GitHub Pages so your files serve as-is.

---

## 🛠 Local Preview (optional)

Just open `index.html` in your browser. No build tools needed.

---

## 📫 Contact

- **Email**: nubiavkleo12@gmail.com  
- © 2025 Nubia Leo — Educational content only (not financial advice).
